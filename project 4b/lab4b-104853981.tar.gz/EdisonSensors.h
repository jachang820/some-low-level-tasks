/*
 * NAME: Jonathan Chang
 * EMAIL: j.a.chang820@gmail.com
 * ID: 104853981
 */

/* uses MRAA library */
void init_temp_sensor(void);
void read_temp_sensor(void);
void deinit_temp_sensor(void);
void init_button(void);
int read_button(void);
void deinit_button(void);

/* setters */
void set_period(float period);
void set_scale(const char c_scale);

/* getters */
float get_period(void);
float get_temperature(void);
